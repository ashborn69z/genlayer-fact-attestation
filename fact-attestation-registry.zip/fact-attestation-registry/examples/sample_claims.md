# Example claims

## Claim 1

Claim:
The Earth revolves around the Sun.

Sources:
https://en.wikipedia.org/wiki/Earth

Expected:
SUPPORTED with high confidence.

## Claim 2

Claim:
A deliberately unsupported statement.

Sources:
https://example.com/

Expected:
INCONCLUSIVE or CONTRADICTED depending on the available evidence.
